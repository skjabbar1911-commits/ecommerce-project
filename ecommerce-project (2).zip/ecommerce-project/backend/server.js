const express = require("express");
const cors = require("cors");
const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

const USD_TO_INR = 87.5;
const categories = ["electronics", "clothing", "books", "accessories", "home", "sports"];

// Local product images — ensure these files exist under frontend/images/
const productImages = [
  "/images/product1.png",        // Product 1 image
  "/images/jacket.jpg",          // Product 2 image
  "/images/book.jpg",            // Product 3 image
  "/images/watch.jpg",           // Product 4 image
  "/images/sofa.jpg",            // Product 5 image
  "/images/racket.jpg",          // Product 6 image
  // Add more image paths for additional products as needed
];

// Optional: custom product names for better display
const productNames = [
  "Election 1",                 // Product 1 name
  "Designer Jacket",
  "Bestselling Novel",
  "Stylish Wristwatch",
  "Modern Sofa Set",
  "Professional Tennis Racket",
  // Add more custom product names as needed
];

const products = Array.from({ length: 50 }, (_, i) => {
  const category = categories[i % categories.length];
  const priceUsd = Math.random() * 100 + 10;

  if (i < productNames.length) {
    // Use custom names and local images for first few products
    return {
      id: i + 1,
      name: productNames[i],
      category,
      price: Math.round(priceUsd * USD_TO_INR),
      deal: Math.random() > 0.7,
      bestseller: Math.random() > 0.3,
      image: productImages[i % productImages.length], // local image path
    };
  }

  // Other products default to generated names and remote Unsplash images
  return {
    id: i + 1,
    name: `${category.charAt(0).toUpperCase() + category.slice(1)} Product ${i + 1}`,
    category,
    price: Math.round(priceUsd * USD_TO_INR),
    deal: Math.random() > 0.7,
    bestseller: Math.random() > 0.3,
    image: `https://source.unsplash.com/300x200/?${category}&sig=${i}`,
  };
});

// Cart items stored in memory
let cart = [];

// API to get products with optional filtering and sorting
app.get("/api/products", (req, res) => {
  let result = [...products];
  const { name, category, minPrice, maxPrice, sort } = req.query;
  if (name) result = result.filter(p => p.name.toLowerCase().includes(name.toLowerCase()));
  if (category) result = result.filter(p => p.category === category);
  if (minPrice) result = result.filter(p => p.price >= parseInt(minPrice));
  if (maxPrice) result = result.filter(p => p.price <= parseInt(maxPrice));
  if (sort === "price-asc") result.sort((a, b) => a.price - b.price);
  if (sort === "price-desc") result.sort((a, b) => b.price - a.price);
  res.json(result);
});

// API for deals of the day
app.get("/api/deals", (req, res) => res.json(products.filter(p => p.deal)));

// API for best sellers
app.get("/api/bestsellers", (req, res) => res.json(products.filter(p => p.bestseller)));

// Cart retrieval
app.get("/api/cart", (req, res) => res.json(cart));

// Add product to cart
app.post("/api/cart", (req, res) => {
  const { productId } = req.body;
  const product = products.find(p => p.id === productId);
  if (!product) return res.status(404).json({ error: "Product not found" });
  const existing = cart.find(item => item.id === productId);
  if (existing) existing.quantity += 1;
  else cart.push({ ...product, quantity: 1 });
  res.json(cart);
});

// Update quantity in cart
app.patch("/api/cart/:productId", (req, res) => {
  const { quantity } = req.body;
  const item = cart.find(p => p.id == req.params.productId);
  if (item) item.quantity = Math.max(1, quantity);
  res.json(cart);
});

// Remove product from cart
app.delete("/api/cart/:productId", (req, res) => {
  const productId = parseInt(req.params.productId);
  cart = cart.filter(p => p.id !== productId);
  res.json(cart);
});

// Start the server
app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
